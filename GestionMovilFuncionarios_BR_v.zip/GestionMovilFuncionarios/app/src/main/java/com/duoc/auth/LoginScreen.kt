package com.duoc.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun LoginScreen() {
    var rut by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var camposVisibles by remember { mutableStateOf(false) }

    // animación 300ms después de cargar la pantalla
    LaunchedEffect(Unit) {
        delay(300)
        camposVisibles = true
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Corporación Municipal de Quilpué", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(32.dp))

        // efecto gradual
        AnimatedVisibility(
            visible = camposVisibles,
            enter = fadeIn(animationSpec = tween(durationMillis = 1200))
        ) {
            Column {
                OutlinedTextField(
                    value = rut,
                    onValueChange = { rut = it },
                    label = { Text("ID o RUT Funcionario") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Contraseña") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { /* Aquí conectaremos el AuthViewModel */ },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Iniciar Sesión")
                }
            }
        }
    }
}