package com.duoc.auth

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("gestion_docs_prefs", Context.MODE_PRIVATE)

    // Guarda el ID y Perfil del usuario tras un login exitoso
    fun guardarSesion(idFuncionario: String, perfil: String) {
        prefs.edit().apply {
            putString("USER_ID", idFuncionario)
            putString("USER_PROFILE", perfil)
            apply()
        }
    }

    // Retorna el ID del usuario actual
    fun obtenerIdUsuarioActivo(): String? {
        return prefs.getString("USER_ID", null)
    }

    // Cierra la sesión limpiando los datos
    fun cerrarSesion() {
        prefs.edit().clear().apply()
    }
}