package com.duoc.documents

import android.Manifest
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.duoc.utils.PermissionUtils

@Composable
fun CapturaDocumentoScreen() {
    val context = LocalContext.current
    var fotoDocumento by remember { mutableStateOf<Bitmap?>(null) }

    // abrir la cámara y recibir la foto
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        fotoDocumento = bitmap // Guarda la foto capturada
    }

    // solicitar el permiso al usuario
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            cameraLauncher.launch(null) // Permiso concedido, abre la cámara
        }
    }

    // La interfaz gráfica
}