package com.duoc.models

data class Funcionario(
    val idFuncionario: String,
    val nombreCompleto: String,
    val centroSalud: String,
    val cargo: String,
    val profesion: String,
    val tipoContrato: String,
    val perfilUsuario: String
)