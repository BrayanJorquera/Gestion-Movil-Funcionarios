package com.duoc.models

object MockData {
    val funcionariosFicticios = listOf(
        Funcionario("F001", "Juan Pérez", "CESFAM Quilpué", "Enfermero", "Salud", "Indefinido", "Funcionario"),
        Funcionario("A001", "Ana Gómez", "Dirección APS", "Administrativa", "Gestión", "Plazo Fijo", "Personal administrativo")
    )

    val documentosFicticios = mutableListOf(
        Documento("DOC-001", "F001", "Certificado de Título", "2023-01-15", "F001", "Aprobado"),
        Documento("DOC-002", "A001", "Contrato Anexo", "2023-06-10", "RRHH", "Vigente")
    )
}