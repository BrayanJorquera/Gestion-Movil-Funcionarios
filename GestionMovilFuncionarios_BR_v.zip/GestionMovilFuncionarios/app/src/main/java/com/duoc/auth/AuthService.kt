package com.duoc.auth

import com.duoc.models.Funcionario
import com.duoc.models.MockData

class AuthService {
    fun loginSimulado(rutUsuario: String, contrasena: String): Funcionario? {

        if (contrasena == "1234") {
            return MockData.funcionariosFicticios.find { it.idFuncionario == rutUsuario }
        }
        return null
    }
}