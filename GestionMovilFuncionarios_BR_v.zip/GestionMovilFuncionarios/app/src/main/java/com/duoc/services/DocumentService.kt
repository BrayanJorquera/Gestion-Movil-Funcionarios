package com.duoc.services

import com.duoc.models.Documento
import com.duoc.models.MockData

class DocumentService {

    // Simular la consulta al repositorio centralizado
    fun obtenerDocumentosPorFuncionario(idFuncionario: String): List<Documento> {
        return MockData.documentosFicticios.filter { it.idFuncionarioAsociado == idFuncionario }
    }

    // Simular la carga de un archivo hacia SharePoint
    fun subirDocumento(nuevoDocumento: Documento): Boolean {
        return try {
            MockData.documentosFicticios.add(nuevoDocumento)
            true // Retorna true si la simulación de subida es exitosa
        } catch (e: Exception) {
            false
        }
    }
}