package com.duoc.models

data class Documento(
    val idDocumento: String,
    val idFuncionarioAsociado: String,
    val tipoDocumento: String,
    val fechaCarga: String,
    val usuarioQueIncorpora: String,
    val estado: String
)